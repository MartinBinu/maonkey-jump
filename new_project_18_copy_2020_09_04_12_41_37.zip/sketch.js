var bg, bgImage;
var ig;
var monkey, monkeyRunning,monkeyCrash;
var BananaGroup,bannanaImage;
var ObstacleGroup,obstacleImage2;
var score = 0;
var bananaCount = 0;

function preload(){
  
  bgImage = loadImage("jungle2.jpg");
  
  monkeyRunning =                               loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  monkeyCrash = loadAnimation("Monkey_01.png");
  
  bananaImage = loadImage("Banana.png");
  
  obstacleImage = loadImage("stone.png");
  
}

function setup() {
  
  createCanvas(400, 400);
  
  bg = createSprite(100,200);
  bg.addImage("bg",bgImage);
  bg.scale = 1;
  
  monkey = createSprite(40,330);
  monkey.addAnimation("monkeyRunning",monkeyRunning);
  monkey.scale = 0.1;
  
  ig = createSprite(200,374,400,30);
  ig.visible = false;
  
  BananaGroup = new Group();
  
  ObstacleGroup = new Group();
  
  RockGroup = new Group();
  
}

function draw() {
  background("white");
  
  edges = createEdgeSprites(); 
    
    bg.velocityX = -(3 + 50*score/100);
  
  
    monkey.collide(ig);
    monkey.collide(edges[2]);
    monkey.scale = 0.1 + bananaCount/100;
  
    monkey.velocityY = monkey.velocityY + 0.6;
  
  
  
    if(keyDown("space")){
      monkey.velocityY = -5;
    }
  
    if(bg.x < 0){
      bg.x = bg.width/2;
   }
  
  if(monkey.isTouching(BananaGroup)){
    BananaGroup.destroyEach();
    score = score + 1;
    bananaCount = bananaCount + 1;
  }
  
  if(monkey.isTouching(ObstacleGroup)){
   bananaCount = 0; 
    secondChance();
    ObstacleGroup.visible = false;
  }
  
   spawnBananas();
   spawnObstacles();
    
  drawSprites();
 
  text("Banana Count: " + bananaCount,10,20)
  
}


function spawnBananas() {
  
 if(frameCount % 120 === 0){ 
  var banana = createSprite(400,300); 
  banana.addImage("banana_1",bananaImage);
  banana.scale = 0.03;
  banana.velocityX = -(3 + 50*score/100)
  banana.y = Math.round(random(100,300));
  banana.lifetime = -1;
  BananaGroup.add(banana); 
   
 }
}
  
function spawnObstacles() {
  
 if(frameCount % 220 === 0){ 
   var obstacles = createSprite(400,350); 
   obstacles.addImage("stone",obstacleImage);
   obstacles.scale = 0.1;
   obstacles.velocityX = -(3 + 50*score/100);
   obstacles.y = Math.round(random(100,350));
   obstacles.lifetime = -1;
   ObstacleGroup.add(obstacles);
   
 }
}
